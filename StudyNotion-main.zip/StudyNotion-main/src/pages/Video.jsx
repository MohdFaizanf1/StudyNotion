import React from 'react'

function Video() {
  return (
    <div>
      
    </div>
  )
}

export default Video
